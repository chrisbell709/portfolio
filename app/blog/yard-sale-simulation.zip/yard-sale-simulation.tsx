"use client"

import { useState, useEffect, useMemo } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Play, Pause, RotateCcw, TrendingUp, Users, DollarSign, BarChart3 } from "lucide-react"

interface Agent {
  id: number
  wealth: number
}

interface SimulationState {
  agents: Agent[]
  round: number
  isRunning: boolean
  history: {
    round: number
    gini: number
    top1Percent: number
    top10Percent: number
    bottom50Percent: number
    averageWealth: number
  }[]
}

export default function YardSaleSimulation() {
  const [simulation, setSimulation] = useState<SimulationState>({
    agents: [],
    round: 0,
    isRunning: false,
    history: [],
  })

  const [currentSection, setCurrentSection] = useState(0)

  const TOTAL_PARTICIPANTS = 1000
  const TOTAL_ROUNDS = 5000
  const INITIAL_WEALTH = 100

  // Initialize simulation
  const initializeSimulation = () => {
    const agents: Agent[] = Array.from({ length: TOTAL_PARTICIPANTS }, (_, i) => ({
      id: i,
      wealth: INITIAL_WEALTH,
    }))

    setSimulation({
      agents,
      round: 0,
      isRunning: false,
      history: [
        {
          round: 0,
          gini: 0,
          top1Percent: 10,
          top10Percent: 10,
          bottom50Percent: 50,
          averageWealth: INITIAL_WEALTH,
        },
      ],
    })
  }

  // Calculate Gini coefficient
  const calculateGini = (agents: Agent[]): number => {
    const sortedWealth = agents.map((a) => a.wealth).sort((a, b) => a - b)
    const n = sortedWealth.length
    const totalWealth = sortedWealth.reduce((sum, w) => sum + w, 0)

    if (totalWealth === 0) return 0

    let giniSum = 0
    for (let i = 0; i < n; i++) {
      giniSum += (2 * (i + 1) - n - 1) * sortedWealth[i]
    }

    return giniSum / (n * totalWealth)
  }

  // Calculate wealth distribution statistics
  const calculateStats = (agents: Agent[]) => {
    const sortedWealth = agents.map((a) => a.wealth).sort((a, b) => b - a)
    const totalWealth = sortedWealth.reduce((sum, w) => sum + w, 0)

    const top1Count = Math.floor(TOTAL_PARTICIPANTS * 0.01)
    const top10Count = Math.floor(TOTAL_PARTICIPANTS * 0.1)
    const bottom50Count = Math.floor(TOTAL_PARTICIPANTS * 0.5)

    const top1Wealth = sortedWealth.slice(0, top1Count).reduce((sum, w) => sum + w, 0)
    const top10Wealth = sortedWealth.slice(0, top10Count).reduce((sum, w) => sum + w, 0)
    const bottom50Wealth = sortedWealth.slice(-bottom50Count).reduce((sum, w) => sum + w, 0)

    return {
      gini: calculateGini(agents),
      top1Percent: (top1Wealth / totalWealth) * 100,
      top10Percent: (top10Wealth / totalWealth) * 100,
      bottom50Percent: (bottom50Wealth / totalWealth) * 100,
      averageWealth: totalWealth / TOTAL_PARTICIPANTS,
    }
  }

  // Run one round of the simulation
  const runRound = (currentAgents: Agent[]): Agent[] => {
    const newAgents = [...currentAgents]
    const interactions = Math.floor(TOTAL_PARTICIPANTS / 2)

    for (let i = 0; i < interactions; i++) {
      const agent1Index = Math.floor(Math.random() * TOTAL_PARTICIPANTS)
      let agent2Index = Math.floor(Math.random() * TOTAL_PARTICIPANTS)

      while (agent2Index === agent1Index) {
        agent2Index = Math.floor(Math.random() * TOTAL_PARTICIPANTS)
      }

      const agent1 = newAgents[agent1Index]
      const agent2 = newAgents[agent2Index]

      const poorerAgent = agent1.wealth < agent2.wealth ? agent1 : agent2
      const richerAgent = agent1.wealth < agent2.wealth ? agent2 : agent1

      if (poorerAgent.wealth > 0) {
        const exchangeFraction = 0.01
        const exchangeAmount = poorerAgent.wealth * exchangeFraction

        if (Math.random() < 0.5) {
          poorerAgent.wealth -= exchangeAmount
          richerAgent.wealth += exchangeAmount
        } else {
          if (richerAgent.wealth >= exchangeAmount) {
            richerAgent.wealth -= exchangeAmount
            poorerAgent.wealth += exchangeAmount
          }
        }

        poorerAgent.wealth = Math.max(0, poorerAgent.wealth)
        richerAgent.wealth = Math.max(0, richerAgent.wealth)
      }
    }

    return newAgents
  }

  // Run simulation step
  const stepSimulation = () => {
    if (simulation.round >= TOTAL_ROUNDS) return

    const newAgents = runRound(simulation.agents)
    const newRound = simulation.round + 1
    const stats = calculateStats(newAgents)

    setSimulation((prev) => ({
      ...prev,
      agents: newAgents,
      round: newRound,
      history: [
        ...prev.history,
        {
          round: newRound,
          ...stats,
        },
      ],
    }))
  }

  // Auto-run simulation
  useEffect(() => {
    if (simulation.isRunning && simulation.round < TOTAL_ROUNDS) {
      const timer = setTimeout(stepSimulation, 10)
      return () => clearTimeout(timer)
    } else if (simulation.round >= TOTAL_ROUNDS) {
      setSimulation((prev) => ({ ...prev, isRunning: false }))
    }
  }, [simulation.isRunning, simulation.round])

  // Initialize on mount
  useEffect(() => {
    initializeSimulation()
  }, [])

  const toggleSimulation = () => {
    setSimulation((prev) => ({ ...prev, isRunning: !prev.isRunning }))
  }

  const resetSimulation = () => {
    initializeSimulation()
  }

  // Create wealth distribution visualization
  const wealthHistogram = useMemo(() => {
    if (simulation.agents.length === 0) return []

    const maxWealth = Math.max(...simulation.agents.map((a) => a.wealth))
    const binCount = 40
    const binSize = maxWealth / binCount
    const bins = Array(binCount).fill(0)

    simulation.agents.forEach((agent) => {
      const binIndex = Math.min(Math.floor(agent.wealth / binSize), binCount - 1)
      bins[binIndex]++
    })

    return bins.map((count, index) => ({
      range: `${(index * binSize).toFixed(0)}-${((index + 1) * binSize).toFixed(0)}`,
      count,
      percentage: (count / TOTAL_PARTICIPANTS) * 100,
    }))
  }, [simulation.agents])

  const currentStats = simulation.history[simulation.history.length - 1] || {
    gini: 0,
    top1Percent: 0,
    top10Percent: 0,
    bottom50Percent: 0,
    averageWealth: 0,
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-indigo-900">
      {/* Header */}
      <header className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-purple-900/50 to-transparent"></div>
        <div className="relative max-w-4xl mx-auto px-6 py-16 text-center">
          <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 tracking-tight">The Yard Sale</h1>
          <p className="text-xl md:text-2xl text-purple-200 mb-8 leading-relaxed">
            A simulation exploring how random economic exchanges lead to wealth inequality over 5,000 rounds
          </p>
          <div className="w-24 h-1 bg-gradient-to-r from-purple-400 to-pink-400 mx-auto rounded-full"></div>
        </div>
      </header>

      {/* Story Section */}
      <section className="max-w-4xl mx-auto px-6 py-16">
        <div className="bg-black/20 backdrop-blur-sm rounded-2xl p-8 mb-12 border border-purple-500/20">
          <p className="text-lg text-purple-100 leading-relaxed mb-6">
            Imagine 1,000 people at a massive yard sale, each starting with exactly{" "}
            <span className="text-yellow-300 font-semibold">$100</span>. They wander around, making small trades with
            each other. Nothing fancy—just random encounters where small amounts of money change hands.
          </p>
          <p className="text-lg text-purple-100 leading-relaxed">
            What happens to wealth distribution when these exchanges are completely random and fair over thousands of
            interactions? The answer might surprise you.
          </p>
        </div>

        {/* Interactive Simulation */}
        <div className="space-y-8">
          {/* Controls */}
          <Card className="bg-black/30 backdrop-blur-sm border-purple-500/30">
            <CardContent className="p-6">
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mb-6">
                <div className="flex items-center gap-4">
                  <Button
                    onClick={toggleSimulation}
                    size="lg"
                    className={`${
                      simulation.isRunning ? "bg-red-600 hover:bg-red-700" : "bg-green-600 hover:bg-green-700"
                    } text-white font-semibold px-6`}
                  >
                    {simulation.isRunning ? (
                      <>
                        <Pause className="h-5 w-5 mr-2" />
                        Pause
                      </>
                    ) : (
                      <>
                        <Play className="h-5 w-5 mr-2" />
                        Start Trading
                      </>
                    )}
                  </Button>
                  <Button
                    onClick={resetSimulation}
                    variant="outline"
                    size="lg"
                    className="border-purple-400 text-purple-200 hover:bg-purple-800/50 bg-transparent"
                  >
                    <RotateCcw className="h-4 w-4 mr-2" />
                    Reset
                  </Button>
                </div>
                <Badge variant="secondary" className="bg-purple-700/50 text-purple-100 px-4 py-2 text-lg">
                  Round {simulation.round} / {TOTAL_ROUNDS}
                </Badge>
              </div>
              <Progress value={(simulation.round / TOTAL_ROUNDS) * 100} className="w-full h-3 bg-purple-900/50" />
            </CardContent>
          </Card>

          {/* Live Stats */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="bg-gradient-to-br from-purple-800/40 to-purple-900/40 backdrop-blur-sm border-purple-500/30">
              <CardContent className="p-6 text-center">
                <div className="flex items-center justify-center mb-3">
                  <BarChart3 className="h-8 w-8 text-purple-300" />
                </div>
                <div className="text-3xl font-bold text-white mb-2">{currentStats.gini.toFixed(3)}</div>
                <div className="text-sm text-purple-200">Gini Coefficient</div>
                <div className="text-xs text-purple-300 mt-1">Inequality measure</div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-red-800/40 to-red-900/40 backdrop-blur-sm border-red-500/30">
              <CardContent className="p-6 text-center">
                <div className="flex items-center justify-center mb-3">
                  <TrendingUp className="h-8 w-8 text-red-300" />
                </div>
                <div className="text-3xl font-bold text-white mb-2">{currentStats.top1Percent.toFixed(1)}%</div>
                <div className="text-sm text-red-200">Top 1% Share</div>
                <div className="text-xs text-red-300 mt-1">Richest 10 people</div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-yellow-800/40 to-orange-900/40 backdrop-blur-sm border-yellow-500/30">
              <CardContent className="p-6 text-center">
                <div className="flex items-center justify-center mb-3">
                  <Users className="h-8 w-8 text-yellow-300" />
                </div>
                <div className="text-3xl font-bold text-white mb-2">{currentStats.top10Percent.toFixed(1)}%</div>
                <div className="text-sm text-yellow-200">Top 10% Share</div>
                <div className="text-xs text-yellow-300 mt-1">Richest 100 people</div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-blue-800/40 to-blue-900/40 backdrop-blur-sm border-blue-500/30">
              <CardContent className="p-6 text-center">
                <div className="flex items-center justify-center mb-3">
                  <DollarSign className="h-8 w-8 text-blue-300" />
                </div>
                <div className="text-3xl font-bold text-white mb-2">{currentStats.bottom50Percent.toFixed(1)}%</div>
                <div className="text-sm text-blue-200">Bottom 50% Share</div>
                <div className="text-xs text-blue-300 mt-1">Poorest 500 people</div>
              </CardContent>
            </Card>
          </div>

          {/* Wealth Distribution Visualization */}
          <Card className="bg-black/30 backdrop-blur-sm border-purple-500/30">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold text-white mb-6 text-center">How Wealth is Distributed Right Now</h3>
              <div className="h-80 w-full mb-6 relative">
                <div className="flex items-end justify-center h-full gap-1 px-4">
                  {wealthHistogram.slice(0, 30).map((bin, index) => {
                    const maxHeight = Math.max(...wealthHistogram.map((b) => b.percentage))
                    const height = maxHeight > 0 ? (bin.percentage / maxHeight) * 100 : 0
                    return (
                      <div
                        key={index}
                        className="bg-gradient-to-t from-purple-500 to-pink-400 flex-1 min-w-0 rounded-t-sm transition-all duration-300"
                        style={{ height: `${height}%` }}
                        title={`Wealth: $${bin.range}, People: ${bin.count} (${bin.percentage.toFixed(1)}%)`}
                      />
                    )
                  })}
                </div>

                {/* Y-axis labels */}
                <div className="absolute left-0 top-0 h-full flex flex-col justify-between text-xs text-purple-300 pr-2">
                  <span>High</span>
                  <span className="text-purple-400">Number of People</span>
                  <span>Low</span>
                </div>

                {/* X-axis labels */}
                <div className="absolute bottom-0 left-0 right-0 flex justify-between text-xs text-purple-300 px-4 pt-2">
                  <span className="text-green-400">Poor ($0-50)</span>
                  <span className="text-yellow-400">Middle ($50-150)</span>
                  <span className="text-red-400">Rich ($150+)</span>
                </div>
              </div>

              <div className="text-center space-y-3">
                <p className="text-purple-200 text-lg">Each bar represents people with similar wealth levels</p>
                <div className="flex justify-center items-center gap-6 text-sm">
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 bg-green-400 rounded"></div>
                    <span className="text-green-300">Low Wealth</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 bg-yellow-400 rounded"></div>
                    <span className="text-yellow-300">Medium Wealth</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 bg-red-400 rounded"></div>
                    <span className="text-red-300">High Wealth</span>
                  </div>
                </div>
                <p className="text-purple-300 text-sm mt-2">
                  Notice how most people cluster on the left (lower wealth) as trading continues
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Explanation */}
          <Card className="bg-black/30 backdrop-blur-sm border-purple-500/30">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold text-white mb-6">Why Does This Happen?</h3>
              <div className="space-y-4 text-purple-100 text-lg leading-relaxed">
                <p>
                  Even though every trade is random and fair, wealth naturally concentrates over time. This happens
                  because of a simple mathematical principle: when you have less money, you have less to lose in each
                  trade, but also less opportunity to win big.
                </p>
                <p>
                  The "yard sale model" demonstrates that inequality can emerge naturally from random processes, without
                  any cheating, skill differences, or unfair advantages. It's a fundamental feature of how wealth flows
                  in economic systems.
                </p>
                <p className="text-yellow-300 font-semibold">
                  This is why many economists argue that some form of redistribution is necessary to maintain economic
                  balance—left alone, random markets tend toward inequality.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="max-w-4xl mx-auto px-6 py-12 text-center">
        <div className="w-24 h-1 bg-gradient-to-r from-purple-400 to-pink-400 mx-auto rounded-full mb-6"></div>
        <p className="text-purple-300 text-sm">
          Based on the econophysics research into wealth distribution and the yard sale model
        </p>
      </footer>
    </div>
  )
}
