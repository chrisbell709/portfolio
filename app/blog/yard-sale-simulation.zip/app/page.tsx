"use client"

import YardSaleSimulation from "../yard-sale-simulation"

export default function Page() {
  return <YardSaleSimulation />
}
